// Express documentation: https://expressjs.com/en/api.html



/* Import the express npm module */
const express = require('express')

/* Instantiate a server object*/
const app = express()
const port = 3000


const BugController = require('./BugController');
const bugController = new BugController();
const UserController = require('./UserController');
const userController = new UserController();
/* Import the body-parser module.  (Used for parsing Post data) */
const bodyParser = require('body-parser');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));







/* Tell the server to use EJS by default */
app.set('view engine', 'ejs');


/* Parse the request body if there is POST data */
app.use(bodyParser.urlencoded({ extended: true }));
//allows you to upload pictures from this directory into the page
app.use(express.static(__dirname + '/pictures'))



/* Display all bugs */
// gets all vacation spots from the bug controller
// asks for all of the bugs and users in the database and constructs
// a table out of them.
app.get('/bugs', (req, res) => {
    bugController.index(req, res);
});


/* Create a new bug */
//updates the bug database and adds a new instance of a bug,
//and puts the parameters in the new instance of the bug
app.post('/bugs', (req, res) => {
    bugController.create(req, res);
    //userController.select(req, res);
  
});


/* Display a form to create a new bug */
//gets the database of all users for the user
app.get('/bugs/new', (req, res) => {
    bugController.newBug(req, res);
});


/* Display a form to create a new bug */
//gets the users and also the bugs
app.get('/login', (req, res) => {
    bugController.login(req, res);
});


//uses login username to customize window
app.post('/username', (req, res) => {


    const username = req.body.id;
    res.send({ string: "Valued customer" });

});


/* Display details for one bug.  
   :id represents a "route parameter" */
//gets one bug
app.get('/bugs/:id', (req, res) => {
    console.log('bugs');
    bugController.show(req, res)
});


/* Edit a bug */
//gets a particular bug
//also gets a list of all users in user database
app.get('/bugs/:id/edit', (req, res) => {
    bugController.edit(req, res)
});



/*Delete a bug */
//gets a particular bug
app.get('/bugs/:id/delete', (req, res) => {
    bugController.delete(req, res);
});

/* Update a bug */
//returns a particular bug to be updated
app.post('/bugs/:id', (req, res) => {
    bugController.update(req, res);
   
});

//Show a selected user
////gets a particular user
app.get('/selectUser', (req, res) => {
    userController.select(req, res);
});

//Post a selected user
//gets a particular user
app.post('/selectUser', (req, res) => {
    userController.showSelected(req, res);
});

/* Display all user */
//gets a list of all users
app.get('/users', (req, res) => {
    userController.index(req, res);
});

/* Create a new User */
//creates a new instance of a user
app.post('/users', (req, res) => {
    userController.create(req, res);
   // userController.select(req, res);
  
});

/* Display a form to create a new bug */
//gets nothing
app.get('/users/new', (req, res) => {
    userController.newUser(req, res);
});


/* Display details for one user.   
   :id represents a "route parameter" */
//gets one user with all its info
   app.get('/users/:id', (req, res) => {
    userController.show(req, res)
});



/* Edit a user */
//gets a user(to edit)
app.get('/users/:id/edit', (req, res) => {
    userController.edit(req, res)
});



/*Delete a user*/
//gets a particular user(to delete)
app.get('/users/:id/delete', (req, res) => {
    userController.delete(req, res);
});

/* Update a user */
//updates a particular id of a user to whatever it was changed to
app.post('/users/:id', (req, res) => {
    userController.update(req, res);
   
});




/* Display details for one user.  
   :id represents a "route parameter" */
//gets one particular user to display
app.get('/users/:id', (req, res) => {
    userController.show(req, res)
});



/* Launch the server */
app.listen(port, () => console.log(`Example app listening on port ${port}!`))