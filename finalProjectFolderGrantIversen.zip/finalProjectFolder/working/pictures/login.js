
document.getElementById('clicked').addEventListener('click', postAuth);


function jsonPost(data) {
    this.method = 'POST'
    this.headers = { 'Content-Type': 'application/json' }
    this.body = JSON.stringify(data)
    return this

}




function postAuth() {
    let route = "/username";
    fetch(route, new jsonPost({ id:0 }))
    .then(res => res.json())
    .then(response => updateState(response))

}
function updateState(data){

    document.getElementById("person").innerHTML = data.name;

}



let submit = document.getElementById('person');
submit.addEventListener('click', submitUser);

function submitUser() {




}